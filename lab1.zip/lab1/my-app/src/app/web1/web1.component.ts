import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web1',
  templateUrl: './web1.component.html',
  styleUrls: ['./web1.component.css']
})
export class Web1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
}
